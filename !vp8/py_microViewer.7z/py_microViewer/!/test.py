from dataclasses import KW_ONLY, dataclass
import socket

#os.system('taskkill /F /T /IM "' + proc +'"')
#os.system("taskkill /F /T /IM {var_list}".format(var_list))

h = "e.open-networks.ru"
p = 443

def status_server(host, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.2)
            if s.connect_ex((host, port)) == 0:
                data_status_server = "Online"
            else:
                data_status_server = "Offline"
    except Exception as e:
        print(e)
    else:
        return data_status_server

print(status_server(h, p))

# https://overcoder.net/q/164793/%D0%BF%D1%80%D0%BE%D0%B2%D0%B5%D1%80%D0%B8%D1%82%D1%8C-%D1%81%D0%BE%D0%BE%D1%82%D0%B2%D0%B5%D1%82%D1%81%D1%82%D0%B2%D1%83%D0%B5%D1%82-%D0%BB%D0%B8-%D1%81%D1%82%D1%80%D0%BE%D0%BA%D0%B0-%D1%88%D0%B0%D0%B1%D0%BB%D0%BE%D0%BD%D1%83-ip-%D0%B0%D0%B4%D1%80%D0%B5%D1%81%D0%B0-%D0%B2-python

a = "255.255.255.1"

def this_is_ip(ip):
    try:
        socket.inet_aton(ip)
        data = "is ip"
    except socket.error:
        data = "is not ip"
    return data

print (this_is_ip(a))

def isgoodipv4(s):
    pieces = s.split('.')
    if len(pieces) != 4: return False
    try: return all(0<=int(p)<256 for p in pieces)
    except ValueError: return False

print(isgoodipv4(a))

def validip(ip):
    return ip.count('.') == 3 and all(0<=int(num)<256 for num in ip.rstrip().split('.'))
for i in ('123.233.42.12','3234.23.453.353','-2.23.24.234','1.2.3.4', "255.255.255.1"):
    print (i,validip(i))

def var_type(data):
    a = data
    isinstance(a, int | str | float)

print(var_type(123))

# Переменная number может принять слядующие типы данных;
def square(number: int | float):
    print(number)

square(1.6)

# Прикольная штукенция;
# from dataclasses import KW_ONLY, dataclass
@dataclass
class Settings:
    ip: KW_ONLY = "127.0.0.1"
    port: int = 5905
    enabled: str = "dsd"

def test(sett: Settings):
    pass

print(Settings.port)

# Еще одна;
# - Было
FileName = str
def get_file(file: FileName):
    pass
# - Стало
from typing import TypeAlias
FileName1: TypeAlias = str
def parse(file: FileName1):
    pass