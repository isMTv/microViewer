from dataclasses import KW_ONLY, dataclass, asdict, fields

@dataclass
class Person:
    first_name: str = "Ahmed"
    last_name: str = "Besbes"
    age: int = 30
    job: str = "Data Scientist"

print("++++++++000++++++++++++")
first_person = Person("123", \
    "321", \
    4, "rrr")
second_person = Person()

print(first_person)
print(second_person)
print(first_person == second_person)
print("++++++++000++++++++++++")

print("++++++++55555++++++++++++")
print(Person)
print(Person())
print("++++++++55555++++++++++++")

print(first_person.age)
print(Person.age)

per = asdict(Person())
print(per)
print(per.values())
for p in per.values():
    print(p)

print("+++++++++++++++++++++++")

@dataclass
class TUNNEL:
    host: str = "open-networks.ru"
    srv_port: str = "4555"
    user_server: str = "super_cl"
    key_server: str = "super_key"

dict_tunnel = asdict(TUNNEL())

print("++++++++1111+++++++++++")
for x in dict_tunnel:
    dict_tunnel_keys = x
    print(dict_tunnel_keys)
print(dict_tunnel)
print(dict_tunnel.values())
for p in dict_tunnel.values():
    print(p)
print("++++++++1111+++++++++++")

# Словарь
for x, p in zip (dict_tunnel, dict_tunnel.values()):
    print(f"key = {x}, value = {p}")

for field in fields(TUNNEL):
    #print(field)
    print(field.name)
    print(field.default)

var = "Service.all"
print(var.replace(".all",""))

class Test:
    ff: str = "123"
    aa: str = "321"

print(Test)

""" # Обновление значений переменных определенных внутри датакласса;
def refresh_dataclasses_vars(data_class):
    for key in eval(data_class).all:
        data = get_config(mv_conf_path, data_class, key)
        command = f'{data_class}.{key} = "{data}"'
        exec(command) """