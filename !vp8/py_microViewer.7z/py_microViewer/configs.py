import configparser


# Создание конфига для ConfSets;
def createconfig_confsets(conf_path):
    config = configparser.ConfigParser()
    config.add_section("ConfSets")
    config.set("ConfSets", "index", "0")
    config.set("ConfSets", "profiles", "['main']")
    with open(conf_path, "w") as config_file:
        config.write(config_file, space_around_delimiters=False)


# Создание конфига для MV;
def createconfig_mv(conf_path):
    config = configparser.ConfigParser()
    config.add_section("MV")
    config.set("MV", "password_length", "7")
    config.set("MV", "connection_type", "id")
    config.set("MV", "mode_server_autorun", "false")
    config.add_section("ABOOK")
    config.set("ABOOK", "index", "0")
    config.set("ABOOK", "profiles", "['abook']")
    config.add_section("Tunnel")
    config.set("Tunnel", "host", "")
    config.set("Tunnel", "port", "22")
    config.set("Tunnel", "user_server", "mv_server")
    config.set("Tunnel", "key_server", "bin/keys/mv_server.ppk")
    config.set("Tunnel", "user_client", "mv_client")
    config.set("Tunnel", "key_client", "bin/keys/mv_client.ppk")
    config.add_section("RemoteDesktop")
    config.set("RemoteDesktop", "port", "5905")
    config.add_section("Server")
    config.set("Server", "id", "")
    config.set("Server", "password", "")
    config.add_section("Service")
    config.set("Service", "enabled", "false")
    config.set("Service", "check_interval", "5")
    config.set("Service", "fix_id_pw", "false")
    config.set("Service", "id", "19000")
    config.set("Service", "password", "")
    config.set("Service", "disable_sleep_mode", "false")
    config.set("Service", "disable_hibernation_mode", "false")
    config.set("Service", "disable_lock_screen", "false")
    config.add_section("Modes")
    config.set("Modes", "service", "false")
    config.add_section("Pids")
    config.set("Pids", "tun_service", "none")
    config.add_section("ParentWindow")
    config.set("ParentWindow", "position_x", "none")
    config.set("ParentWindow", "position_y", "none")
    with open(conf_path, "w") as config_file:
        config.write(config_file, space_around_delimiters=False)


# Создание конфига для RD;
def createconfig_rd(conf_path):
    config = configparser.ConfigParser()
    config.add_section("ClientMode")
    config.set("ClientMode", "default", "")
    config.set("ClientMode", "password", "")
    config.set("ClientMode", "ip", "127.0.0.1")
    config.set("ClientMode", "port", "5905")
    config.set("ClientMode", "boot", "")
    config.set("ClientMode", "control", "1")
    config.set("ClientMode", "encryption", "0")
    config.set("ClientMode", "videocodec", "3")
    config.set("ClientMode", "videoquality", "2")
    config.set("ClientMode", "scroll", "0")
    config.set("ClientMode", "sound", "2")
    config.set("ClientMode", "soundcapture", "1")
    config.set("ClientMode", "soundquality", "3")
    config.set("ClientMode", "topwindow", "0")
    config.set("ClientMode", "caption", "1")
    config.set("ClientMode", "soundcache", "100")
    config.set("ClientMode", "maxfps", "30")
    config.set("ClientMode", "monochrome", "0")
    config.set("ClientMode", "zoomlock", "0")
    config.set("ClientMode", "filemovedialog", "1")
    config.add_section("ServerMode")
    config.set("ServerMode", "default", "")
    config.set("ServerMode", "password", "")
    config.set("ServerMode", "port", "5905")
    config.set("ServerMode", "boot", "")
    config.set("ServerMode", "control", "1")
    config.set("ServerMode", "publicmode", "1")
    config.set("ServerMode", "passwordwait", "2")
    config.set("ServerMode", "relaymode", "0")
    config.set("ServerMode", "relayip", "")
    config.set("ServerMode", "relayport", "")
    config.set("ServerMode", "maxfps", "0")
    config.set("ServerMode", "filemovedialog", "1")
    config.add_section("Global")
    with open(conf_path, "w") as config_file:
        config.write(config_file, space_around_delimiters=False)


# Редактирование конфига;
def edit_config(conf_path, section, settings, value):
    config = configparser.ConfigParser()
    config.read(conf_path)
    config.set(section, settings, value)
    with open(conf_path, "w") as config_file:
        config.write(config_file, space_around_delimiters=False)


# Получение значений;
def get_config(conf_path, section, settings):
    config = configparser.ConfigParser()
    config.read(conf_path)
    value = config.get(section, settings)
    return value


# Удаление значений;
def remove_config(conf_path, section, settings):
    config = configparser.ConfigParser()
    config.read(conf_path)
    config.remove_option(section, settings)
    with open(conf_path, "w") as config_file:
        config.write(config_file, space_around_delimiters=False)
